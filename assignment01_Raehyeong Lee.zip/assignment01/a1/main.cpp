#include <iostream>
#include <cstdio>

int main() {
    // Print out your name using stream IO
    std::cout << "Raehyeong Lee" << std::endl;
    // Print out your name using printf
    printf("Raehyeong Lee\n");

    // Print out the result of computing 25 / 7 using stream IO
    std::cout << "Result of 25/7 using stream IO: " << 25/7 << std::endl;
    // Print out the result of computing 25 / 7 using printf
    printf("Result of 25/7 using printf: %d\n", 25/7);

    // Print out the result of computing 25.0 / 7.0 using stream IO
    std::cout << "Result of 25.0/7.0 using stream IO: " << 25.0/7.0 << std::endl;
    // Print out the result of computing 25.0 / 7.0 using printf
    printf("Result of 25.0/7.0 using printf: %g\n", 25.0/7.0);

    /* Add a comment explaining why the two results are different.
     * The %d placeholder is for integers, while %g is for floating-point numbers.
     * As a result, using the placeholder %d with printf and stream IO for the floating-point calculation results can lead to incorrect outputs.
    */

    return 0;
}