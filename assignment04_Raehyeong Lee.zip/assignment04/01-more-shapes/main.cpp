
#include "GLM/gtc/type_ptr.hpp"
#include <glad/gl.h>
#include "learnopengl/shader_4722.h"
#include "cs4722/artifact.h"
#include "cs4722/window.h"
#include "cs4722/buffer_utilities.h"

static std::vector<cs4722::artifact*> artifact_list;
static Shader *shader;

void init(void)
{
    shader = new Shader("../01-more-shapes/vertex_shader.glsl" ,
                        "../01-more-shapes/fragment_shader.glsl" );
    shader->use();

    glEnable(GL_PROGRAM_POINT_SIZE);
    glEnable(GL_DEPTH_TEST);

    cs4722::shape* b = new cs4722::block();
    auto* artf = new cs4722::artifact();
    artf->the_shape = b;
    artf->world_transform.translate = glm::vec3(-.5, -.5, 0);
    artf->world_transform.scale = glm::vec3(.75f, .25f, .5f);
    artf->world_transform.rotation_angle = (M_PI / 4);

    artf->world_transform.rotation_axis = glm::vec3(1, 0, 0);
    artifact_list.push_back(artf);

    auto* artf1 = new cs4722::artifact();
    artf1->the_shape = b;
    artf1->world_transform.translate = glm::vec3(-.5, .5, 0);
    artf1->world_transform.scale = glm::vec3(.75f, .25f, .5f);
    artf1->world_transform.rotation_angle = ((M_PI*7) / 4 );

    artf1->world_transform.rotation_axis = glm::vec3(0, 1, 0);
    artifact_list.push_back(artf1);

    auto* artf2 = new cs4722::artifact();
    artf2->the_shape = b;
    artf2->world_transform.translate = glm::vec3(.5, -.5, 0);
    artf2->world_transform.scale = glm::vec3(.75f, .25f, .5f);
    artf2->world_transform.rotation_angle = (M_PI / 2 );

    artf2->world_transform.rotation_axis = glm::vec3(0, 0, 1);
    artifact_list.push_back(artf2);

    auto* artf3 = new cs4722::artifact();
    artf3->the_shape = b;
    artf3->world_transform.translate = glm::vec3(.5, .5, 0);
    artf3->world_transform.scale = glm::vec3(.75f, .25f, .5f);
    artf3->world_transform.rotation_angle = ((M_PI*3) / 2 );

    artf3->world_transform.rotation_axis = glm::vec3(1, 0, 0);
    artifact_list.push_back(artf3);

    cs4722::init_buffers(shader->ID, artifact_list, "b_position", "b_color");
}


void render()
{
    for (auto artf : artifact_list) {
        auto model_matrix = artf->animation_transform.matrix()
                            * artf->world_transform.matrix();
        shader->setMat4("u_transform", model_matrix);
        glDrawArrays(GL_TRIANGLES, artf->the_shape->buffer_start, artf->the_shape->buffer_size);
    }
}

int
main(int argc, char** argv)
{
    glfwInit();
    cs4722::set_opengl_version(3,3);
    GLFWwindow* window = cs4722::setup_window("More Shapes", .6, 1);
    glfwMakeContextCurrent(window);
    gladLoadGL(glfwGetProcAddress);
    init();
    while (!glfwWindowShouldClose(window))
    {
        glClearBufferfv(GL_COLOR, 0, cs4722::x11::gray50.as_float_array());
        glClear(GL_DEPTH_BUFFER_BIT);
        render();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
}
