

#include <GLM/gtc/matrix_inverse.hpp>
#include <GLM/gtc/type_ptr.hpp>

#include <glad/gl.h>

#include "learnopengl/shader_4722.h"

#include "cs4722/view.h"
#include "cs4722/artifact.h"
#include "cs4722/texture_utilities.h"
#include "cs4722/buffer_utilities.h"
#include "cs4722/window.h"
#include "callbacks.h"



static cs4722::view *the_view;
static Shader *shader;
static std::vector<cs4722::artifact*> artifact_list;


void init()
{

    the_view = new cs4722::view();
    the_view->set_flup(
    glm::vec3(0.011578,0.0499792,-0.998684),
    glm::vec3(-0.999933,0,-0.0115925),
    glm::vec3(-0.000579383,0.998751,0.0499759),
    glm::vec3(2.77569,-0.204956,3.79724)
    );

    the_view->enable_logging = false;
    shader = new Shader("../vertex_shader.glsl","../fragment_shader.glsl");
    shader->use();

    glEnable(GL_DEPTH_TEST);


//    cs4722::init_texture_from_file("../media/729144-real-myst-windows-screenshot-beautiful-detail-in-the-graphics.png", 1);
    cs4722::init_checkerboard_texture(1,8,0,255,256);

    cs4722::shape* b = new cs4722::sphere();
    b->color_set_ = std::vector<cs4722::color>({cs4722::x11::gray50, cs4722::x11::gray75});
    // b->color_set_ = std::vector<cs4722::color>({cs4722::x11::blue, cs4722::x11::green});

    auto const diffuse_color_common = cs4722::x11::olive_drab;

    auto* artf = new cs4722::artifact();
    artf->the_shape = (b);
    artf->world_transform.translate = (glm::vec3(0, 2, 0));
    artf->world_transform.scale = (glm::vec3(.4f, .6f, .4f));
    artf->surface_material.diffuse_color = diffuse_color_common;
    artf->texture_unit = 1;
    artf->surface_effect = 0;
    artifact_list.push_back(artf);


    artf = new cs4722::artifact();
    artf->the_shape = (b);
    artf->world_transform.translate = (glm::vec3(2, 2, 0));
    artf->world_transform.scale = (glm::vec3(.4f, .6f, .4f));
    artf->surface_material.diffuse_color = diffuse_color_common;
    artf->texture_unit = 1;
    artf->surface_effect = 1;
    artifact_list.push_back(artf);


    artf = new cs4722::artifact();
    artf->the_shape = (b);
    artf->world_transform.translate = (glm::vec3(4, 2, 0));
    artf->world_transform.scale = (glm::vec3(.4f, .6f, .4f));
    artf->surface_material.diffuse_color = diffuse_color_common;
    artf->texture_unit = 1;
    artf->surface_effect = 2;
    artifact_list.push_back(artf);

    artf = new cs4722::artifact();
    artf->the_shape = (b);
    artf->world_transform.translate = (glm::vec3(6, 2, 0));
    artf->world_transform.scale = (glm::vec3(.4f, .6f, .4f));
    artf->surface_material.diffuse_color = diffuse_color_common;
    artf->texture_unit = 1;
    artf->surface_effect = 3;
    artifact_list.push_back(artf);

    artf = new cs4722::artifact();
    artf->the_shape = (b);
    artf->world_transform.translate = (glm::vec3(0, -2, 0));
    artf->world_transform.scale = (glm::vec3(.4f, .6f, .4f));
    artf->surface_material.diffuse_color = diffuse_color_common;
    artf->texture_unit = 1;
    artf->surface_effect = 4;
    artifact_list.push_back(artf);

    artf = new cs4722::artifact();
    artf->the_shape = (b);
    artf->world_transform.translate = (glm::vec3(2, -2, 0));
    artf->world_transform.scale = (glm::vec3(.4f, .6f, .4f));
    artf->surface_material.diffuse_color = diffuse_color_common;
    artf->texture_unit = 1;
    artf->surface_effect = 5;
    artifact_list.push_back(artf);

    artf = new cs4722::artifact();
    artf->the_shape = (b);
    artf->world_transform.translate = (glm::vec3(4, -2, 0));
    artf->world_transform.scale = (glm::vec3(.4f, .6f, .4f));
    artf->surface_material.diffuse_color = diffuse_color_common;
    artf->texture_unit = 1;
    artf->surface_effect = 6;
    artifact_list.push_back(artf);

    artf = new cs4722::artifact();
    artf->the_shape = (b);
    artf->world_transform.translate = (glm::vec3(6, -2, 0));
    artf->world_transform.scale = (glm::vec3(.4f, .6f, .4f));
    artf->surface_material.diffuse_color = diffuse_color_common;
    artf->texture_unit = 1;
    artf->surface_effect = 7;
    artifact_list.push_back(artf);

    artf = new cs4722::artifact();
    artf->the_shape = (b);
    artf->world_transform.translate = (glm::vec3(0, -2, 0));
    artf->world_transform.scale = (glm::vec3(.4f, .6f, .4f));
    artf->surface_material.diffuse_color = diffuse_color_common;
    artf->texture_unit = 1;
    artf->surface_effect = 3;
    artifact_list.push_back(artf);

    cs4722::init_buffers(shader->ID, artifact_list,
                         "bPosition",
                         "bColor",
                         "bTextureCoord");
}

void render()
{
    auto view_transform = glm::lookAt(the_view->camera_position,
                                      the_view->camera_position + the_view->camera_forward,
                                      the_view->camera_up);
    auto projection_transform = glm::infinitePerspective(the_view->perspective_fovy,
                                                         the_view->perspective_aspect, the_view->perspective_near);
    auto vp_transform = projection_transform * view_transform;


    for (auto artf : artifact_list) {
        glm::mat4 model_transform = artf->animation_transform.matrix() * artf->world_transform.matrix();
        shader->setMat4("u_transform", vp_transform*model_transform);

        shader->setInt("sampler2", artf->texture_unit);
        shader->setInt("surface_effect", artf->surface_effect);
        shader->setVec4("diffuse_color", artf->surface_material.diffuse_color.as_float_array());

        glDrawArrays(GL_TRIANGLES, artf->the_shape->buffer_start, artf->the_shape->buffer_size);
    }
}


int
main(int argc, char** argv)
{
    glfwInit();
    cs4722::set_opengl_version(3,3);
    GLFWwindow* window = cs4722::setup_window_9_16_9("Different Effects");
    gladLoadGL(glfwGetProcAddress);

    init();
    the_view->perspective_aspect = (float)cs4722::get_aspect_ratio(window);

    glfwSetWindowUserPointer(window, the_view);

    glfwSetKeyCallback(window, general_key_callback);
    glfwSetCursorPosCallback(window, move_callback);
    glfwSetWindowSizeCallback(window, window_size_callback);
	
    while (!glfwWindowShouldClose(window))
    {
        glClearBufferfv(GL_COLOR, 0, cs4722::x11::gray50.as_float_array());
        glClear(GL_DEPTH_BUFFER_BIT);
        render();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);

    glfwTerminate();
}
