

#include "GLM/gtc/type_ptr.hpp"
#include <glad/gl.h>

#include "learnopengl/shader_4722.h"

#include <vector>
#include <cs4722/artifact.h>
#include <cs4722/window.h>
#include "cs4722/buffer_utilities.h"

static Shader *shader;



static std::vector<cs4722::artifact*> artifact_list;

void init(void)
{
    shader = new Shader("../problemA/vertex_shader.glsl" ,"../problemA/fragment_shader.glsl" );
    glUseProgram(shader->ID);

    glEnable(GL_DEPTH_TEST);




    cs4722::shape* block = new cs4722::block();
    auto* artf = new cs4722::artifact_rotating();
    artf->the_shape = block;
    artifact_list.push_back(artf);


    artf = new cs4722::artifact_rotating();
    artf->the_shape = block;
    artifact_list.push_back(artf);


    cs4722::init_buffers(shader->ID, artifact_list, "b_position", "b_color");

}



void render()
{

    static auto last_time = 0.0;
    auto time = glfwGetTime();
    auto delta_time = time - last_time;
    last_time = time;

    for (auto artf : artifact_list) {
        artf->animate(time, delta_time);
        auto model_matrix = artf->animation_transform.matrix()
                            * artf->world_transform.matrix();
        shader->setMat4("u_transform", model_matrix);
        glDrawArrays(GL_TRIANGLES, artf->the_shape->buffer_start, artf->the_shape->buffer_size);
    }
}

int
main(int argc, char** argv)
{
    glfwInit();
    cs4722::set_opengl_version(3, 3);
    GLFWwindow *window = cs4722::setup_window("Problem A", .6, 1);
    gladLoadGL(glfwGetProcAddress);
    init();
    while (!glfwWindowShouldClose(window))
    {
        glClearBufferfv(GL_COLOR, 0, cs4722::x11::gray50.as_float_array());
        glClear(GL_DEPTH_BUFFER_BIT);
        render();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
}
