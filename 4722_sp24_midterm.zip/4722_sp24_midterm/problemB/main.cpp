
#include <vector>

#include "GLM/gtc/type_ptr.hpp"
#include <glad/gl.h>

#include "learnopengl/shader_4722.h"
#include "cs4722/artifact.h"
#include "cs4722/window.h"
#include "cs4722/buffer_utilities.h"

static std::vector<cs4722::artifact*> artifact_list;

static Shader *shader;

void init()
{
    shader = new Shader("../problemB/vertex_shader.glsl" ,"../problemB/fragment_shader.glsl" );
    shader->use();

    glEnable(GL_DEPTH_TEST);

    auto* shape = new cs4722::cylinder(.4, 21);

    /*
     * Change the color_set_ of the shape to using two levels of gray.
     * This will give a darker/lighter pattern of the material color over the surface.
     */
    auto gray_level0 = .80;
    auto gray_level1 = .90;
    shape->color_set_ = std::vector<cs4722::color>({cs4722::color(gray_level0, gray_level0, gray_level0, 1.0),
                                                    cs4722::color(gray_level1, gray_level1, gray_level1, 1.0)});
    auto number = 5;
    auto d = 4.0 / (2 * number + 1);
    auto radius = d / 4;
    auto base = -1 + 3 * radius;

    for (auto x = 0; x < number; ++x)
    {
        for (auto y = 0; y < number; ++y)
        {
            for (auto z = 0; z < number; ++z)
            {
                auto* artf = new cs4722::artifact_rotating();
                artf->the_shape = shape;
                artf->world_transform.translate = glm::vec3(base + x * d, base + y * d, base + z * d);
                artf->world_transform.scale = glm::vec3(radius, radius, radius);
                artf->animation_transform.rotation_axis = glm::vec3(3 * x + 1, 3 * y + 1, 3 * z + 1);
                artf->animation_transform.rotation_center =
                        artf->world_transform.matrix() * glm::vec4(-1, 0, 0, 1);
                artf->rotation_rate = M_PI / 3 * pow(z+1, .5);
                artifact_list.push_back(artf);
            }
        }
    }
    cs4722::init_buffers(shader->ID, artifact_list, "b_position", "b_color");
}


void render()
{

    static auto last_time = 0.0;
    auto time = glfwGetTime();
    auto delta_time = time - last_time;
    last_time = time;

    // uncomment the following few lines to see the frame rate computed two different ways
    static double  arate = 0.0;
    auto x = (100 * arate + 1 / delta_time) / 101;
    arate  = x;

    for (auto artf : artifact_list) {
        artf->animate(time, delta_time);
        auto model_matrix = artf->animation_transform.matrix() * artf->world_transform.matrix();
        shader->setMat4("u_transform", model_matrix);
        glDrawArrays(GL_TRIANGLES, artf->the_shape->buffer_start, artf->the_shape->buffer_size);
    }
}

int main()
{
    glfwInit();
    cs4722::set_opengl_version(3, 3);
    GLFWwindow *window = cs4722::setup_window("Problem B", .6, 1);
    gladLoadGL(glfwGetProcAddress);
    init();
    while (!glfwWindowShouldClose(window))
    {
        glClearBufferfv(GL_COLOR, 0, cs4722::x11::gray50.as_float_array());
        glClear(GL_DEPTH_BUFFER_BIT);
        render();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
}
